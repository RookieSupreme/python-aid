from window import Ui_MainWindow #导入主窗体UI类
#导入PyQt5包中的相关模块
from PyQt5 import QtCore,QtGui,QtWidgets
#导入PyQt5模块中的相关类
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
#导入系统模块
import sys
#导入自定义的获取车站中文即对应英文的文件和车站起售时间的文件模块
from get_stations import *
#导入自定义的查询模块
from query_request import *
#导入系统的时间模块
from datetime import datetime,timedelta
import time


#窗口初始化类
class Main(QMainWindow,Ui_MainWindow):
    def __init__(self):
        super(Main,self).__init__()
        self.setupUi(self) #建立界面及控件
        self.table_2() #初始化选项卡2中的表格
        self.model = QStandardItemModel()   # 创建数据模型
        # 根据空间自动改变列宽度并且不可修改列宽度
        self.tableView.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.pushButton.clicked.connect(self.on_click) #绑定车票查询按钮方法(槽)
        self.checkBox_G.stateChanged.connect(self.type_select) #绑定高铁复选框方法
        self.checkBox_D.stateChanged.connect(self.type_select) #绑定动车复选框方法
        self.checkBox_Z.stateChanged.connect(self.type_select) #绑定直达复选框方法
        self.checkBox_T.stateChanged.connect(self.type_select) #绑定特快复选框方法
        self.checkBox_K.stateChanged.connect(self.type_select) #绑定快车复选框方法

    #初始化选项卡2的表头内容及格式
    def table_2(self):
        #设置列数为9
        self.tableWidget.setColumnCount(9)
        # 设置表头各列的名称
        self.tableWidget.setHorizontalHeaderLabels(['车次', '出发站', '到达站', '出发时间', '到达时间', '历时', '今天', '三天内', '五天内'])
        # 设置表头背景色为天空蓝
        self.tableWidget.horizontalHeader().setStyleSheet("QHeaderView::section{background:skyblue;}")
        self.tableWidget.horizontalHeader().setStretchLastSection(True)  # 设置表头充满表宽度
        self.tableWidget.setStyleSheet('background-color:white')  # 设置表格整体背景色
        self.tableWidget.horizontalHeader().setVisible(True)  # 设置显示表头
        self.tableWidget.setEditTriggers(QTableView.NoEditTriggers) #设置表格内容不可编辑

    def on_click(self):
        fs = self.textEdit.toPlainText() #获取输入的出发地
        ts = self.textEdit_2.toPlainText() #获取输入的目的地
        date = self.textEdit_3.toPlainText() #获取输入的出发时间
        #判断车站文件是否存在
        if is_stations('stations.text') == True:
            #读取所有车站并转换为字典类型
            stations = eval(read('stations.text'))
            #判断所有参数是否为空
            if fs != "" and ts != "" and date != "":
                #判断输入的车站名是否存在,以及时间格式是否正确
                if fs in stations and ts in stations and self.is_valid_date(date):
                    #计算时间差
                    time_difference = self.time_difference(date)
                    #判断时间是否在当天的30天以内
                    if time_difference >=0 and time_difference <=29:
                        #在车站文件中找到对应的url参数
                        from_station = stations[fs] #出发地
                        to_station = stations[ts] #目的地
                        #发送查询请求,并获得返回信息
                        data = query(date,from_station,to_station,fs,ts)
                        #设置复选框默认情况
                        self.checkBox_default()
                        if len(data) != 0:
                            #数据不为空,将显示在界面表格中
                            self.displayTable(len(data),16,data)
                        else:
                            #若查询结果无数据,弹出警告提示框
                            messageDialog("警告","没用返回的网络数据!")
                    else:
                        #若查询日期不在30天以内,弹出警告提示框
                        messageDialog("警告","超出查询日期范围!")
                else:
                    #若输入的地点不存在或时间格式不对,弹出警告提示框
                    messageDialog("警告","输入站名不存在,或日期格式不正确!")
            else:
                #若地点或时间没有填写就点击查询,弹出提示警告框
                messageDialog("警告","请填写车站名称!")
        else:
            #若预先没下载好车站对照文件或车站起售时间文件,弹出提示警告框
            messageDialog("警告","未下载车站查询文件")

    def type_select(self):
        """
        复选框绑定函数,根据勾选的车次类型显示相应数据
        :return: None
        """
        if not data:
            #若未点击查询就勾选复选框时,不做任何相应
            return
        #将所有复选框按顺序构成列表
        checkBoxs = [self.checkBox_G,self.checkBox_D,self.checkBox_Z,self.checkBox_T,self.checkBox_K]
        #用于存放具体的车次类型
        info = []
        #将复选框列表变为枚举类型,并遍历获得每个复选框及其对应的索引
        for index,item in enumerate(checkBoxs):
            #如果复选框为勾选状态
            if item.isChecked():
                #获得对应的车次类型的二维列表
                for i in type_data[index]:
                    #添加进定义好的列表中
                    info.append(i)
            #如果遍历完成并且数据不为空
            if index == 4 and info:
                #打破循环,接下来的else将不执行
                break
        else:
            #如果正常遍历完后,说明没有一个复选框为选中状态，将显示所有车次信息
            info = data
        #调用显示方法,将信息显示在界面中
        self.displayTable(len(info), 16, info)

    def is_valid_date(self,date):
        """
        判断时间参数格式是否正确
        :param date: 目标时间
        :return: bool值
        """
        try:
            #匹配日期是否在合理范围内,如月份超过12,天数超过31将会出现异常
            time.strptime(date,"%Y-%m-%d")
            #分割字符串,获得年月日
            dlist = date.split("-")
            #分析月和日的格式是否为xx,比如说1也要写成01,因为根据请求的url的参数要求
            if len(dlist[1]) == 2 and len(dlist[2]) == 2:
                return True
            else:
                return False
        except:
            #出现异常,返回False表示时间不对
            return False

    # def get_time(self):
    #     """
    #     获取当前日期
    #     :return: 时间字符串
    #     """
    #     return time.strftime("%Y-%m-%d",time.localtime())

    def time_difference(self,date):
        """
        获取时间差
        :param date: 目标时间,字符串类型
        :return: 时间差,整型
        """
        #分割时间字符串
        dlist = date.split("-")
        #将分割好的字符串年月日转为整数传入datetime,返回datetime对象
        utime = datetime(int(dlist[0]),int(dlist[1]),int(dlist[2]))
        #获取当前日期并加上29天,表示只能查询30天以内的,返回datetime对象
        stime = datetime.now() + timedelta(days=29)
        #获取时间差值,返回datedelta对象
        time_difference = stime - utime
        return time_difference.days  #将datedelta对象中days属性(即时间差值返回),为整型

    def checkBox_default(self):
        """
        设置复选框默认为未选中情况
        :return:None
        """
        #将复选框对象反复列表中
        checkBoxs = [self.checkBox_G,self.checkBox_D,self.checkBox_Z,self.checkBox_T,self.checkBox_K]
        for checkBox in checkBoxs:
            #循环遍历,将复选框设置为未打钩的状态
            checkBox.setChecked(False)

    def displayTable(self,trains,info,data):
        """
        将数据显示在界面表格中
        :param trains: 车次数量
        :param info:每辆车次有多少条信息
        :param data:需要显示的数据
        :return:None
        """
        # 清空模型里的所有数据
        self.model.clear()
        #循环获取数据
        for row in range(trains):
            for col in range(info):
                #获取数据中的内容
                item = QStandardItem(data[row][col])
                #向表格存储模式中添加表格具体信息
                self.model.setItem(row,col,item)
                self.model.item(row,col).setTextAlignment(Qt.AlignCenter) #数据内容居中显示
        self.model.sort(3, Qt.AscendingOrder)  # 按发车时间进行升序排列
        self.tableView.setModel(self.model)  # 绑定表格数据模型




def show_MainWindow():
    """
    启动程序,整个项目的开始
    :return:None
    """
    app = QApplication(sys.argv)  # 创建QApplication对象,作为GUI主程序入口
    main = Main()  # 创建主窗体对象
    main.textEdit_3.setText(time.strftime("%Y-%m-%d",time.localtime()))  # 出发日显示当天日期
    main.show()  # 显示主窗体
    sys.exit(app.exec_())  # 主循环启动程序,等待退出后,结束主进程

def messageDialog(title,message):
    """
    显示消息提示框
    :param title: 提示框标题
    :param message: 提示内容
    :return: None
    """
    #由PyQt5创建一个弹框对象,Warining表示弹框为警告弹框
    msg_box = QMessageBox(QMessageBox.Warning,title,message)
    #执行提示框
    msg_box.exec_()

def exist_file():
    """
    判断静态资源文件是否存在
    :return: None
    """
    #判断车站文件是否存在
    if is_stations('stations.text') == False:
        #不存在则创建
        get_station()
    #判断时间文件是否存在
    if is_stations('time.text') == False:
        #不存在则创建
        get_selling_time()
    #若不能正确创建,则弹出警告框提示,并退出主进程
    if not (is_stations('stations.text') == True and is_stations('time.text') == True):
        messageDialog('警告','车站文件或起售文件出现异常!')
        sys.exit(0)

if __name__ == "__main__":
    #启动程序前进行文件判断
    exist_file()
    #启动程序,直至退出
    show_MainWindow()
