import requests
import re
import os
import json

def get_station():
    """
    获取查询时中文车站名与请求时查询地址的参数对应关系
    :return:None
    """
    #车站名与对应请求参数的链接地址
    url= "https://kyfw.12306.cn/otn/resources/js/framework/station_name.js?station_version=1.9101"
    #以GET方式获取url链接地址的全部内容,返回requests库中的response对象,承载着整个url对应的资源
    response = requests.get(url,verify=True)#verity为12个访问控制中的一个可选参数,为认证SSL证书开关,默认为True
    #利用正则表达式匹配中文站名与其对应的英文缩写
    #正则表达式中的[\u4e00-\u9fa5]表示:\u后跟一个十六进制的Unicode编码,而4e00-9fa5为基本的中文字符
    #text为response对象的一个属性,可获取字符串形式的响应体内容
    #获得的stations为列表,里面为中文站名与其英文缩写两个元素构成的元组
    stations = re.findall(r'([\u4e00-\u9fa5]+)\|([A-Z]+)',response.text)
    #将列表转换为字典,使其有更好的对应意义,方便后面的查找
    stations = dict(stations)
    #将字典转换为字符串类型,否则无法写入到文件里
    stations = str(stations)
    #调用方法,将内容写入到stations.text文件里
    write(stations,"stations.text")

def get_selling_time():
    """
    获取车站起售时间
    :return: None
    """
    #12306网站的车站起售时间的JSON格式数据链接
    url = "https://www.12306.cn/index/script/core/common/qss_v10029.js"
    #以GET的方式请求对应url,将响应相关的内容以response承载
    response = requests.get(url)
    #将有用的数据以正则表达式获取,json_str为列表,里面只有一个json格式的元素(带引号的字典),字典里站名为key,起售时间为value
    json_str = re.findall(r'{[^}]+}',response.text)
    # print(json_str)
    #由于json格式为带引号的字典,并会显示/n/t,因此需将其转为python的字典类型
    #利用python第三方库json中的方法转换,得到的time_js为python的字典
    time_js = json.loads(json_str[0])
    # print(time_js)
    #将字典类型转为字符串,以写入到文件中
    time_str = str(time_js)
    #调用wirte方法,将数据写入文件中
    write(time_str,'time.text')

def write(stations,file_name):
    """
    将数据写入到文件中
    :param stations:车站信息 字符串类型
    :param file_name: 文件名  字符串类型
    :return: None
    """
    #以写模式打开文件
    file = open(file_name,'w')
    #将数据写入文件中
    file.write(stations)
    #关闭文件
    file.close()

def read(file_name):
    """
    读取文件内容
    :param file_name: 指定的文件名 字符串类型
    :return: 文件内容  字符串类型
    """
    #以读方式打开文件
    file = open(file_name,'r')
    #获取文件里所有数据
    data = file.read()
    #关闭文件
    file.close()
    return data

def is_stations(file_name):
    """
    判断文件是否存在
    :param file_name:目标文件名 字符串类型
    :return: 布尔值,存在返回True,否则False
    """
    #判断文件是否存在,status为布尔值
    status = os.path.exists(file_name)
    return status

if __name__ == "__main__":
    # get_station()
    print(is_stations('stations.text'))
    # print(read('stations.text'))
    # get_selling_time()
    pass






