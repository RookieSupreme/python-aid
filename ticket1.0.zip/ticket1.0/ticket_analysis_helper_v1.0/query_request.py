from get_stations import *
import urllib.parse #导入标准库模块，用于对中文进行转码
from fetch_proxy_ip import *

data = []          #用于保存整理好的车次信息
type_data = []     #保存车次分类后的数据

def query(train_date,from_station,to_station,fs,ts):
    """
    获取查询车次信息
    :param train_date: 出发时间,字符串类型,格式"xxxx-xx-xx"
    :param from_station: 出发站,字符串类型,格式"大写英文"
    :param to_station: 目的地,字符串类型,格式"大写英文"
    :return: 每辆车次信息为一列表构成的二维列表
    """
    # 清空之前查询的数据
    del data[:len(data)]
    #通过给定的参数拼成完整车票查询链接
    url = "https://kyfw.12306.cn/otn/leftTicket/query?leftTicketDTO.train_date={}&leftTicketDTO.from_station={}&leftTicketDTO.to_station={}&purpose_codes=ADULT".format(
    train_date,from_station,to_station)
    #将出发地中文字符串转换为url中文参数格式
    fs = urllib.parse.quote(fs)
    #将目的地中文字符串转换为url中文参数格式
    ts = urllib.parse.quote(ts)
    #拼接请求来源，告知服务器在哪个url发起请求
    referer = 'https:// kyfw.12306.cn/otn/leftTicket/init?linktypeid=dc&fs={},{}& ts={},{}&date={}&flag =N,N,Y'.format(fs,from_station,ts,to_station,train_date)
    #伪造请求头信息，如下伪造了用户代理，请求来源的url和请求的服务器
    header = {'user-agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.75 Safari/537.36',
              'referer':referer,
              'host':'kyfw.12306.cn'}
    #判断运行前爬取的代理IP是否可用
    if validateIp("http://120.25.90.253:8118"):
        # 使用爬取过来的代理IP
        pxs = {"http":"http://120.25.90.253:8118"}
    else:
        #不可用使用本地IP，即不设置代理服务器
        pxs={}
    try:
        #以GET方式发起请求
        response = requests.get(url,headers=header,proxies=pxs)
        #如果状态码不是200，抛出HTTPError异常
        response.raise_for_status()
    except:
        #打印‘产生异常’,以便分析是否url错误还是IP地址失效
        print("产生异常")
        #结束方法
        return
    #将JSON数据转换为字典类
    result = response.json()
    #通过键值对获取车票信息,result为列表类型,每个元素对应一辆车次的信息
    result = result['data']['result']
    #判断车站文件是否存在
    if is_stations('stations.text') == True:
        #将读取到的字符串内容转换为字典类型
        stations = eval(read('stations.text'))
        #判断返回的数据是否为空
        if len(result) != 0:
            #遍历,获取每辆车次
            for each_train in result:
                #分割数据并存放在列表中
                #3:车次 6:出发站 7:目的地 8:出发时间 9:达到时间 10:历时 21:高级软卧 23:软卧 24:软座
                #26:无座 28:硬卧 29:硬座 30:二等座 31:一等座 32:商务特等座 33:动卧
                tmp_list = each_train.split('|')
                #由于分割出来的站名为英文,因此需从车站文件中找到对应的中文站名
                from_station = list(stations.keys())[list(stations.values()).index(tmp_list[6])]
                to_station = list(stations.keys())[list(stations.values()).index(tmp_list[7])]
                #创建车次列表,将有用的信息按显示顺序放入
                train = [tmp_list[3],from_station,to_station,tmp_list[8],tmp_list[9],tmp_list[10],tmp_list[32],
                         tmp_list[31],tmp_list[30],tmp_list[21],tmp_list[23],tmp_list[33],tmp_list[28],
                         tmp_list[24],tmp_list[29],tmp_list[26]]
                #由于座位中有空值,需转换为'--';将"无"转为"候补"
                new_train = []
                for t in train:
                    if t == "":
                        t = "--"
                    elif t == "无":
                        t = "候补"
                    #将最终数据放入一个新列表里
                    new_train.append(t)
                #每辆车次信息为一列表放入之前定义好的列表里,构成二维列表
                data.append(new_train)
        #调用自定义方法,划分车次类型
        type_train()
        #在判断数据是否为空处返回,无数据将返回空列表
        return data

def type_train():
    """
    将查询到的所有车次信息按种类分好
    :return: 分好车次种类的列表,索引0:GC开头  1:D开头  2:Z开头 3: T开头 4:K开头
    """
    #创建各类列表,将对应车次信息的存入,形成二维列表
    GC_train = []
    D_trian = []
    Z_trian = []
    T_trian = []
    K_trian = []
    #遍历整理好的查询数据
    for train in data:
        #依次判断车次开头,存入对应的列表里
        if train[0][0] == "G":
            GC_train.append(train)
        elif train[0][0] == "C":
            GC_train.append(train)
        elif train[0][0] == "D":
            D_trian.append(train)
        elif train[0][0] == "Z":
            Z_trian.append(train)
        elif train[0][0] == "T":
            T_trian.append(train)
        elif train[0][0] == "K":
            K_trian.append(train)
    #清空之前查询到的数据
    del type_data[:len(type_data)]
    #将所有种类的车次放入之前建立好的列表里
    type_data.append(GC_train)
    type_data.append(D_trian)
    type_data.append(Z_trian)
    type_data.append(T_trian)
    type_data.append(K_trian)
    # return type_data



if __name__ == "__main__":
    # query(train_date='2019-06-10',from_station='GZQ',to_station='NNZ')
    # data = type_train()
    # print(data)
    pass


