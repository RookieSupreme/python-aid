import requests    #用于发起请求
from bs4 import BeautifulSoup   #用于解析网页内容
import random   #导入随机模块

"""
    爬取国内透明免费代理IP地址
"""

proxies = []  #用于存放有用的IP地址
# index = -1

def getOneAvailableProxy():
    """
    获取一个有用的IP地址
    :return: 字典类型，key为协议，字符串类型，value为IP地址，字符串类型
    """
    #引用外部变量，变为全局变量
    global proxies
    if len(proxies) == 0:
        #若无内容，调用方法获取
        proxies = fetchAvalableProxyIpList()
    # global index
    # if index < 0:
    #     index = random.randint(0, len(proxies) - 1)
    #随机获取一个
    index = random.randint(0,len(proxies))
    return proxies[index]

# def setTheProxyInavalid():
#     global index
#     index = -1

def fetchAvalableProxyIpList():
    """
    获取有用的IP地址
    :return:
    """
    # proxies = []
    #调用方法获取IP
    for proxy in getProxyIp():
        #以字典形式存入定义好的列表中
        proxies.append({'http': proxy[0]})
    return proxies


def _requestUrl(index):
    """
    请求url，获取网页数据
    :param index: 获取的网页页数
    :return: HTML网页内容 字符串类型
    """
    #网页源地址
    src_url = 'http://www.xicidaili.com/nt/'
    #拼接url
    url = src_url + str(index)
    if index == 0:
        #若只获取第一页，则无需拼接
        url = src_url
    #设置请求头中的用户代理
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:43.0) Gecko/20100101 Firefox/43.0'
    }
    #以GET方式发起网络请求
    response = requests.get(url, headers=headers)
    #返回获得的网页内容
    return response.text


def parseProxyIpList(content):
    """
    解析网页数据，获取ip和端口信息
    :param content: HTML网页内容
    :return: IP列表
    """
    list = []
    #创建BeautifulSoup对象，用html解析器解析内容
    soup = BeautifulSoup(content, 'html.parser')
    #获取所有的tr标签内容，以表列返回
    ips = soup.find_all('tr')
    #遍历，以获取每个tr标签里的内容
    for x in range(1, len(ips)):
        #获取每个tr标签里的所有td标签内容，返回列表
        tds = ips[x].find_all('td')
        #找到关键内容的位置，通过contents获取子节点对应的内容，并拼接为完整的IP地址
        ip_temp = 'http://' + tds[1].contents[0] + ':' + tds[2].contents[0]
        print('发现ip：%s' % ip_temp)
        list.append(ip_temp)
    return list


def filterValidProxyIp(list):
    """
    过滤，获取有效的ip信息
    :param list: 爬取获取到的所有IP地址字符串列表
    :return: 有用的IP字符串列表
    """
    print('开始过滤可用ip 。。。')
    validList = [] #用于存放有用的IP字符串
    for ip in list:
        #调用法方法，验证是否有用
        if validateIp(ip):
            print('%s 可用' % ip)
            #能用则添加进来
            validList.append(ip)
        else:
            print('%s 无效' % ip)
    #返回刷选过后的结果
    return validList


def validateIp(proxy):
    """
    验证ip是否有效
    :param proxy: 字符串IP地址
    :return: 布尔值
    """
    #设置代理IP
    proxy_temp = {"http": proxy}
    #验证IP是否有效的url
    url = "http://ip.chinaz.com/getip.aspx"
    try:
        #发起请求，超过5秒无反应，抛出超时异常
        requests.get(url, proxies=proxy_temp, timeout=5)
        return True
    except:
        return False


def getProxyIp():
    """
    获取可用的代理ip列表
    :return: 代理IP二维列表
    """
    allProxys = [] #用于存放可用的代理IP
    startPage = 0  #开始页
    endPage = 1  #结束页
    #获取每页中可用的代理IP
    for index in range(startPage, endPage):
        print('查找第 %s 页的ip信息' % index)
        # 请求url，获取网页数据
        content = _requestUrl(index)
        # 解析网页数据，获取ip和端口信息
        list = parseProxyIpList(content)
        # 过滤有效的ip信息
        list = filterValidProxyIp(list)
        # 添加到有效列表中
        allProxys.append(list)
        print('第 %s 页的有效ip有以下：' %(index+1))
        print(list)
    print('总共找到有效ip有以下：')
    print(allProxys)
    return allProxys

if __name__ == '__main__':
    # proxies = getProxyIp()
    ip = getOneAvailableProxy()
    print(ip)
