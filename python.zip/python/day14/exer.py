import re
import sys

port = sys.argv[1]

f = open('1.txt')

#找到port段落
while True:
    data = ''
    for line in f:
        if line !='\n':
            data += line
        else:
            break
    print(">>>>>",data)
    if not data:
        break

    key_word = re.match(r'\S+',data).group()
    print(key_word)
    if port == key_word:

        pattern = r'[0-9a-f]{4}\.[0-9a-f]{4}\.[0-9a-f]{4}'
        address = re.search(pattern,data).group()
        print(address)
        break








