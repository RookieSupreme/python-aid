import turtle
def tree(n):
    if n > 5:
# 右边树
        turtle.forward(n)
        turtle.right(20)
        tree(n-15)
# 这里画完右边树后，笔的位置应该在最右边顶点上，为什么不用写返回的语句，就可以直接画左边树？
# 左边树
        turtle.left(40)
        tree(n-15)
# 返回
        turtle.right(20)
        turtle.backward(n)
def main():
    turtle.left(90)
    turtle.backward(50)
    tree(80)
    turtle.exitonclick()
if __name__ == '__main__':
    main()