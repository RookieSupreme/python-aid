import re

s = "hello world how are you L-boby"
pattern = r"(\w+)+:(\d+)"
pattern2 = r"[^\w]+"
l = re.split(pattern2,s)
print(l)

s = "我草你妈"

ns = re.sub(r"[草妈]",'*',s)
print(ns)