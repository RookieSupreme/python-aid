import re

s = """Hello world
你好,北京
"""
#只能匹配ascii匹配码
# regex = re.compile(r'\w+',flags = re.A)
#忽略字母大小写
# regex = re.compile(r'[a-z]+',flags = re.I)
#匹配换行
regex = re.compile(r'.+',flags=re.S)
l = regex.findall(s)
print(l)







