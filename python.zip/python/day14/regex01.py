import re

s = "2019年,建国70周年"

pattern = r"\d+"

it = re.finditer(pattern,s)

for i in it:
    print(i.group())

m = re.fullmatch(r'\w+',"world1973")
print(m.group())

k = re.match(r'[A-Z]\w*','Hello World')
print(k.group())

j = re.search(r'\S+','   好\n嗨 呦')
print(j.group())





