#match对象属性
import re

pattern = r"(ab)cd(?P<pig>ef)"

regex = re.compile(pattern)

#获取match对象
obj = regex.search("abcdefghi",pos = 0,endpos = 7)

#属性变量
print(obj.pos)#目标字符串开头位置
print(obj.endpos)#目标字符串结束位置
print(obj.re)#正则
print(obj.string)#目标字符串
print(obj.lastgroup)#最后一组名称
print(obj.lastindex)#最后一组序号

#属性方法
print(obj.start())
print(obj.end())
print(obj.span())
print(obj.groupdict())
print(obj.groups())

