from day02.code01 import *

text = "sadasda0sdsad()sadsadwd"

parens = "()[]{}"
left_parens = "([{"
opposite = {')':'(',']':'[','}':'{'}


def parent(text):
    i,len_text = 0,len(text)
    while True:
        while i < len_text and text[i] not in parens:
            i += 1
        if i >= len_text:
            return
        else:
            yield text[i],i
            i +=1
st = SStack()
for pr,i in parent(text):
    if pr in left_parens:
        st.push((pr,i))
    elif st.is_empty() or st.pop()[0] != opposite[pr]:
        print("Unmatching is found at %d for %s" % (i, pr))
        break
else:
    if st.is_empty():
        print("没有多余的括号")
    else:
        e = st.pop()
        print("多出来的括号是第%d个%s" % (e[1] + 1, e[0]))






