class StackError(Exception):
    pass

class SStack:
    """
    基于列表实现顺序栈
    """
    def __init__(self):

        self._list01 = []

    def top(self):
        """
        栈顶
        :return:
        """

        if not self._list01:
            raise StackError("异常")
        return self._list01[-1]

    def is_empty(self):
        """
        判断是否为空列表
        :return:
        """
        return self._list01 == []

    def push(self,elem):
        """
        入栈
        :param elem:
        :return:
        """
        self._list01.append(elem)

    def pop(self):
        """
        出栈
        :return:
        """
        if not self._list01:
            raise StackError("异常")
        return  self._list01.pop()





if __name__ == "__main__":
    st = SStack()
    # print(st.top())
    print(st.is_empty())
    st.push(10)
    st.push(20)
    st.push(30)
    while not st.is_empty():
        print(st.pop())













