"""
　栈的链式结构
"""

class StackError(Exception):
    pass

class Node():
    def __init__(self,val,next=None):
        self.val = val
        self.next = next

class LStack:
    def __init__(self):
        self.top = None

    def is_empty(self):
        return self.top is None

    def push(self,val):
        self.top = Node(val,self.top)

if __name__ == "__main__":
    st = LStack()
    print(st.is_empty())