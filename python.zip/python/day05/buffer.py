fd = open("text","w",12)
while True:
    s = input(">>")
    fd.write(s + "\n")
    fd.flush()
