

fd = open("/home/tarena/data/day05/text","r")

print(fd.read())
print(fd.tell())
fd.seek(3,0)
print(fd.tell())
