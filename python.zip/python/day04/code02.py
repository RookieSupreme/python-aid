class Sort:

    def __init__(self, list_):
        self.list_ = list_


    def bubble(self):
        for i in range(len(self.list_)-1):
            for j in range(len(self.list_) - i - 1):
                if self.list_[j] > self.list_[j+1]:
                    self.list_[j],self.list_[j+1] = self.list_[j+1],self.list_[j]

    def select(self):
        for i in range(len(self.list_)-1):
            min = i
            for j in range(i+1,len(self.list_)):
                if self.list_[i] > self.list_[j]:
                    min = j
            if min != i:
                self.list_[i],self.list_[min] = self.list_[min],self.list_[i]

    def insert(self):
        for i in range(1,len(self.list_)):
            x = self.list_[i]
            j = i
            while j > 0 and self.list_[j-1] > x:
                self.list_[j] = self.list_[j-1]
                j -= 1
            self.list_[j] = x



