fd = open("/home/tarena/text","ab")

a = "\n你好啊"

fd.write(a.encode())

fd.close()