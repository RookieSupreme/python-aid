import multiprocessing as mp
from time import sleep,ctime
def tm():
    for i in range(3):
        sleep(2)
        print(ctime())

p = mp.Process(target=tm,name='tedu')
p.daemon = True
p.start()
print("name:",p.name)
print("pid:",p.pid)
print("is alive:",p.is_alive())

