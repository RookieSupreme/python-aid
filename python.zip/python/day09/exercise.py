from multiprocessing import Process



def fun(file_name,num_seek):
    file = open("/home/tarena/data/day09/text", "rb")
    file.seek(num_seek)
    op_file = open(file_name, "w")
    while True:







n = len(file.read())
p1 = Process(target=fun,args=(0,))
p2 = Process(target=fun,args=(n//2,))
p1.start()
p2.start()
p1.join()
p2.join()


