from time import sleep,ctime
from multiprocessing import Pool

def fun1(msg):
    sleep(2)
    print(msg)

pool = Pool(2)
for i in range(20):
    msg = "hello %d"%i
    pool.apply_async(func = fun1, args = (msg,))

pool.close()

pool.join()







