"""
链试队列
"""

class Node():
    def __init__(self,val,next=None):
        self.val = val
        self.next = next

class QueueError(Exception):
    pass

class StackQueue():
    def __init__(self):
        self.list01 = []
        self.top = Node(None)
        self.end = self.top

    def is_empty(self):
        return self.top == self.end

    def push(self,val):

        self.end.next = Node(val)
        self.end = self.end.next
        # r = self.end
        # r.next = Node(val)
        # r = r.next

    def pop(self):
        if not self.is_empty():
            raise QueueError("*****")
        p = self.top
        self.top = p.next
        return p.val

    def show(self):
        p = self.top.next

        while p != None:
            print(p.val, end=' ')
            p = p.next
        print()

if __name__ == "__main__":

    p = StackQueue()
    p.push(2)
    p.push(3)
    p.push(4)
    p.push(5)
    p.show()
    # while not p.is_empty():
    #     print(p.pop())



