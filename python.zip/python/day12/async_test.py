import asyncio
import time
now = lambda : time.time()

async def do_work(x):
    print("waiting:",x)
    await asyncio.sleep(x)
    return "Done after %s s"%x

strat = now()

cor1 = do_work(1)
cor2 = do_work(2)
cor3 = do_work(3)

tasks = [
    asyncio.ensure_future(cor1),
    asyncio.ensure_future(cor2),
    asyncio.ensure_future(cor3)

]
#得到轮寻对象
loop = asyncio.get_event_loop()
loop.run_until_complete(asyncio.wait(tasks))

print("time:",now()-strat)



