"""
select函数
"""

from socket import *
from select import  select

#做几个io用来监控
s = socket()
s.bind(('176.140.6.138',8888))
s.listen(3)

rs,ws,xs = select([s],[],[])

print("rs:",rs)
print("ws:",ws)
print("xs:",xs)










