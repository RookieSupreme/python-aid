from socket import *
from time import  sleep

dest = ('176.140.6.255',9999)

s = socket(AF_INET,SOCK_DGRAM)

s.setsockopt(SOL_SOCKET,SO_BROADCAST,1)

while True:
    sleep(0.01)
    data = """*******************
              *******************
              *******************
              *******************
              *******************"""

    s.sendto(data.encode(),dest)

s.close()