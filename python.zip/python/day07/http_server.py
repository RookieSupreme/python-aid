"""
将网页发送给浏览器
"""
from socket import *


# 处理浏览器的http请求
def handle(connfd):
    print("request from", connfd.getpeername())
    request = connfd.recv(4096)
    if not request:
        return
    request_line = request.splitlines()[0].decode()
    info = request_line.split(' ')[1]
    if info == "/":
        f = open("/home/tarena/data/day07/index.html")
        response = "HTTP/1.1 200 OK\r\n"
        response += "Content-Type: text/htm\r\n"
        response += "\r\n"
        response += f.read()
    else:
        response = "HTTP/1.1 200 OK\r\n"
        response += "Content-Type: text/htm\r\n"
        response += "\r\n"
        response += "<h1>sorry...</h1>"

    connfd.send(response.encode())


def main():
    s = socket()
    s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
    s.bind(("", 8046))
    s.listen(3)
    print("listen the port 8000...")
    while True:
        connfd, addr = s.accept()
        handle(connfd)  # 处理浏览器请求
        connfd.close()


if __name__ == "__main__":
    main()
