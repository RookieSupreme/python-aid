
from socket import *
import struct

s = socket(AF_INET,SOCK_DGRAM)

s.bind(('',8888))

st = struct.Struct('i20sif')
file = open("/home/tarena/data/day07/text", "a")

while True:
    data,addr = s.recvfrom(1024)
    data = st.unpack(data)
    info = "%d %s %d %.2f"%(data[0],data[1].decode(),data[2],data[3])

    file.write(info)

file.close()
s.close()
















