from socket import *

import struct

addr = ('',8888)

st = struct.Struct('i32sif')
s = socket(AF_INET,SOCK_DGRAM)

while True:
    id = int(input("id:"))
    name = input("name:").encode()
    age = int(input("age:"))
    score = float(input("score:"))

    data = st.pack(id,name,age,score)

    s.sendto(data,addr)

s.close()