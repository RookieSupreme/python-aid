from  socket import *
# 创建tcp套接字

s = socket()
s.bind(('0.0.0.0',8045))
s.listen(3)
c,addr = s.accept()
print("connect from:",addr)

data = c.recv(4096)
print(data)
data = """HTTP/1.1 200 OK
Content-Type:text/html
 
<h1>hello world</h1>
<h1>大家按回复即可很快来到吉安山东科技</h1>
"""
c.send(data.encode())

c.close()
s.close()
