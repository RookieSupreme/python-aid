import os
from time import *


def f1():
    for i in range(4):
        sleep(2)
        print("1")

def f2():
    for i in range(5):
        sleep(2)
        print("2")



pid = os.fork()

if pid < 0:
    print("error")
elif pid == 0:
    p = os.fork()
    if p == 0:
        f2()
    else:
        os._exit(0)
else:
    os.wait()
    f1()



