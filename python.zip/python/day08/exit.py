import os
import sys

os._exit(1)
print("process exit")