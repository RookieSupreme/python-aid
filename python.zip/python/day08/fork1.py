import os

pid = os.fork()

if pid < 0:
    print("1")
elif pid == 0:
    print("2")
else:
    print("3")