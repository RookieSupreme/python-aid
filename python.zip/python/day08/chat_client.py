from socket import *
import os,sys

ADDR = ("176.140.6.138 ",9999)

#发送消息
def send_msg(s,name):
    while True:
        try:
            text = input("发言:")
        except KeyboardInterrupt:
            text = 'quit'
        if text == 'quit':
            msg = 'Q ' + name
            s.sendto(msg.encode(),ADDR)
            sys.exit("\n退出聊天")
        msg = "C %s %s"%(name,text)
        s.sendto(msg.encode(),ADDR)

#接受消息
def recv_msg(s):
    while True:
        data,addr = s.recvfrom((2048))
        #服务器发送exit表示让客户端退出
        if data.decode() == 'EXIT':
            sys.exit()
        print(data.decode() + '\n发言:',end ='')



def main():
    s = socket(AF_INET,SOCK_DGRAM)
    while True:
        name = input("请输入姓名:")
        msg = "L " + name
        s.sendto(msg.encode(),ADDR)
        data,addr = s.recvfrom(1024)
        if data.decode() == "OK":
            print("\n成功进入聊天")
            break
        else:
            print(data.decode())

    #创建新进程

    pid = os.fork()
    if pid < 0:
        sys.exit("error")
    elif pid == 0:
        send_msg(s,name)
    else:
        recv_msg(s)


if __name__ == "__main__":
    main()

