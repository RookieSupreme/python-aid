import os
from time import *

pid = os.fork()

if pid < 0:
    print("1")
elif pid == 0:
    sleep(5)
    print("2")
else:
    sleep(4)
    print("3")

print("4")