import os

pid = os.fork()

if pid < 0:
    print("error")
elif pid == 0:
    print("child pid:",os.getpid())
    print("parent pid:", os.getppid())
else:
    print("parent pid:",os.getpid())
    print("child pid:", pid)
