from greenlet import greenlet
import gevent



def test1():
    print("start1")
    gr2.switch()
    print("end1")

def test2():
    print("start2")
    print("end2")

gr1 = greenlet(test1)
gr2 = greenlet(test2)

gr1.switch()
gr1.switch()

def foo(a,b):
    print("runing foo...",a,b)
f = gevent.spawn(foo,1,'hello')