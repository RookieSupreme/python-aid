"""
    tcp 套接字服务端
"""

import socket

sockfd = socket.socket(socket.AF_INET,socket.SOCK_STREAM,proto=0)

sockfd.bind(('0.0.0.0',8888))


# 设置监听
sockfd.listen(5)
while True:
    #　等待客户端链接
    print("waiting for connect...")

    connfd,addr = sockfd.accept()
    print("connect from:",addr)

    while True:
    #　收发消息
        data = connfd.recv(1024)
        if not data:
            break
        print("接受到的消息：",data.decode())

        n = connfd.send('收到'.encode())
        print("发送了%d个字节数据"%n)

#　关闭套接字
connfd.close()
sockfd.close()










