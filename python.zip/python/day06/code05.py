from socket import *

s = socket()
s.setsocketopt(SOL_SOCKET,SO_REUSEPORT)
c = socket(AF_INET,SOCK_STREAM)
s.bind(('176.140.6.146',8888))

s.listen(5)

print(s.type)
print(s.family)
print(s.getsockname())
print(s.fileno())