"""
    UPD客户端
"""
from socket import *

sockfd = socket(AF_INET,SOCK_DGRAM)
server_addr = ('176.140.6.146',9999)

while True:
    you_put = input(">>")
    if not you_put:
        break
    sockfd.sendto(you_put.encode(),server_addr)
    data,addr = sockfd.recvfrom(1024)
    print("from server:",data.decode())

sockfd.close()