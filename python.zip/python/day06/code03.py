"""
    UDP套接字服务器
"""
from socket import *

sockfd = socket(AF_INET,SOCK_DGRAM)

sockfd.bind(('0.0.0.0',8888))
while True:
    data,addr = sockfd.recvfrom(1024)
    print("收到的消息:",data.decode(),"来自:",addr)
    sockfd.sendto("收到".encode(),addr)

sockfd.close()