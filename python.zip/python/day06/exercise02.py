from socket import *

sockdf = socket()
try:
    sockdf.connect(('176.140.6.138',8888))
except KeyboardInterrupt:
    print("退出服务")
# file = open("/home/tarena/data/day06/text","rb")

while True:
    file = input(">>")
    val = open(file,"rb")
    data = val.read()
    if not val:
        break

    n = sockdf.send(data)
    print("发送成功！发送了%d个字节"%n)
    data = sockdf.recv(1024)
    print("来自服务器的消息：",data.decode())


