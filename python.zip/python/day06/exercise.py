"""

"""
from socket import *

s = socket(AF_INET,SOCK_STREAM)

s.bind(('176.140.6.138',8888))

s.listen(5)
while True:
    print("waiting for connect...")
    connfd,addr = s.accept()
    print("连接至:", addr,"\n等待数据传输...")
    file = open("/home/tarena/data/day06/text02.odg", "rb")
    while True:
        data = connfd.recv(1024)
        if not data:
            break
        print("接受成功!")
        n = connfd.send("已收到".encode())


s.close()
socket.close()