from threading import Thread
from time import sleep


class ThereadClass(Thread):
    def __init__(self,attr):
        self.attr = attr
        super().__init__()

    def f1(self):
        print("步骤1",self.attr)
    def f2(self):
        print("步骤2")

    def run(self):
        self.f1()
        self.f2()
t = ThereadClass("xxxxx")
t.start()
t.join()

