from threading import Thread
import time
from multiprocessing import Process

def count(x,y):
    c = 0
    while c < 7000000:
        c += 1
        x += 1
        y += 1
def io():
    write()
    read()
def write():
    f = open("test","w")
    for i in range(1500000):
        f.write("hello world")
    f.close()
def read():
    f = open("test","r")
    f.readlines()
    f.close()

s1 = time.time()
for i in range(10):
    count(1,1)
s2 = time.time()
print(s2-s1)

s1 = time.time()
jobs = []
for i in range(10):
    t = Thread(target=io)
    jobs.append(t)
    t.start()

for i in jobs:
    i.join()

s2 = time.time()
print("十个线程一次io计算时间:",s2 - s1)

s1 = time.time()
for i in range(10):
    t = Thread(target=count,args = (1,1))
    t.start()
    t.join()
s2 = time.time()
print("10个线程1次密集计算时间:",s2 - s1)

s1 = time.time()
for i in range(10):
    p = Process(target=count,args = (1,1))
    p.start()
    p.join()
s2 = time.time()
print("10个进程1次密集计算时间:",s2 - s1)

jobs = []
s1 = time.time()
for i in range(10):
    p = Process(target=io)
    jobs.append(p)
    p.start()

for i in jobs:
    i.join()

s2 = time.time()
print("10个进程1次io计算时间:",s2 - s1)





