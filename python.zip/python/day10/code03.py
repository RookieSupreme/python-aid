from threading import Thread
from time import sleep

def fun():
    sleep(3)
    print("线程属性测试")

t = Thread(target=fun)

# 线程名称
print("线程名称:",t.getName())