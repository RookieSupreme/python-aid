"""
线程
"""
import threading,os
from time import sleep


a = 1

def music():
    global a
    print(a)
    a = 10000
    for i in range(5):
        sleep(2)
        print("播放<心如止水>",os.getpid())

t = threading.Thread(target=music)
t.start()

#主线程任务
for i in range(5):
    sleep(1)
    print("跳舞",os.getpid())

t.join()

print(a)