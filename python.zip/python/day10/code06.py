from threading import Thread,Event


s = None
e = Event()
def 杨子龙():
    print("杨子龙牛逼")
    global s
    s = "天王盖地虎"
    e.set()

t = Thread(target=杨子龙)
t.start()
print("口令是啥")
e.wait()
if s == "天王盖地虎":
    print("宝塔镇河妖")
else:
    print("打死他")
t.join()


