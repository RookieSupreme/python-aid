import time
import threading

#交易类
class Account:
    def __init__(self,id,balance,lock):
        self.id = id
        self.balance = balance
        self.lock = lock
    #取钱
    def withdraw(self,amount):
        self.balance -= amount

    # 存钱
    def deposit(self, amount):
        self.balance += amount

    def get_balance(self):
        return self.balance

# 转账函数

def transfer(from_,to,amount):
    if from_.lock.acquire(): #锁住自己的账户
        from_.withdraw(amount)
        if to.lock.acquire():#对方账户上锁
            to.deposit(amount)
            to.lock.release()#对方账户解锁
        from_.lock.release()#自己账户解锁
    print("转账完成")




abby = Account('abby',5000,threading.Lock())
vivo = Account('vivo',8000,threading.Lock())

t = threading.Thread(target=transfer,args = (abby,vivo,1500))
t.start()
t.join()

print("abby",abby.get_balance())
print("vivo",vivo.get_balance())




