"""
    tcp 客户端
"""
from socket import *

sockfd = socket()
server_addr = ('176.140.6.138',8888)
sockfd.connect(server_addr)
while True:
    you_put = input(">>")
    if not you_put:
        break
    sockfd.send(you_put.encode())
    data = sockfd.recv(1024)
    print("from server:",data.decode())

sockfd.close()

