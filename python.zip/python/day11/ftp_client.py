from socket import *
import sys
import time

# 具体功能
class Ftpclient:
    def __init__(self,sockfd):
        self.sockfd = sockfd

    def do_list(self):
        self.sockfd.send(b'L')# 发送请求
        #等待回复
        data = self.sockfd.recv(128).decode()

        if data == 'OK':
            while True:
                data = self.sockfd.recv(4096)
                print(data.decode())
                break
        else:
            print(data)

    def do_quit(self):
        self.sockfd.send(b'Q')
        self.sockfd.close()
        sys.exit("谢谢使用")

    def do_get(self,filename):
        # 发送请求
        self.sockfd.send(("G " + filename).encode())
        #等待回复
        data = self.sockfd.recv(128).decode()
        if data == "OK":
            fd = open(filename,"wb")
            #接受内容写入文件
            while True:
                data = self.sockfd.recv(1024)
                if data == b'##':
                    print("下载完成")
                    break
                fd.write(data)
            fd.close()
        else:
            print(data)

    def do_put(self,filename):
        try:
            f = open(filename,'rb')
        except Exception:
            print("没有文件")
            return
        #发送请求
        filename = filename.spilt('/')[-1]
        self.sockfd.send(('P ' + filename).encode())
        #等待回复
        data = self.sockfd.recv(128).decode()
        if data == "OK":
            while True:
                data = f.read(1024)
                if not data:
                    time.sleep(0.1)
                    self.sockfd.send(b'##')
                    break
                self.sockfd.send(data)
            f.close()
        else:
            print(data)


def request(sokefd):
    ftp = Ftpclient(sokefd)
    while True:
        print("\n========命令选项========")
        print("\n******* list   ********")
        print("\n*******get file********")
        print("\n*******put file********")
        print("\n********quit   ********")

        cmd = input("请输入命令:")
        if cmd.strip() == 'list':
            ftp.do_list()
        elif cmd[:3] == 'get':
            filename = cmd.strip().split(" ")[-1]
            ftp.do_get(filename)
        if cmd[:3] == 'put':
            filename = cmd.strip().split(" ")[-1]
            ftp.do_put(filename)
        if cmd.strip() == 'quit':
            ftp.do_quit()


# 网络链接
def main():
    sockfd = socket()
    server_addr = ('176.140.6.138', 9999)

    try:
        sockfd.connect(server_addr)
    except Exception as e:
        print("链接失败")
        return
    else:
        print("""                 *******************
                 data   file   image
                 *******************
        """)
        cls = input("请输入文件类别:")
        if cls not in ["data","file","image"]:
            print("input error!")
            return
        else:
            sockfd.send(cls.encode())
            request(sockfd) # 发送具体请求

    # while True:
    #     you_put = input(">>")
    #     if not you_put:
    #         break
    #     sockfd.send(you_put.encode())
    #     data = sockfd.recv(1024)
    #     print("from server:", data.decode())
    #
    # sockfd.close()

if __name__ == "__main__":
    main()
